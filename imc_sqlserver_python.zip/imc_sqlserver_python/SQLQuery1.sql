CREATE DATABASE IMC_DB;
GO

USE IMC_DB;
GO

CREATE TABLE pacientes (
    id INT PRIMARY KEY IDENTITY(1,1),
    nome NVARCHAR(100),
    peso FLOAT,
    altura FLOAT,
    imc FLOAT,
    classificacao NVARCHAR(50)
);